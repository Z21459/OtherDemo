some tools for writing lua code. 
test on lua 5.2, mac os x, gcc 4.2.1.
